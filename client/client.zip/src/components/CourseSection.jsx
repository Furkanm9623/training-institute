// import React from "react";
// import { FaBuilding, FaCogs, FaDraftingCompass, FaCalculator } from "react-icons/fa";

// const CoursesSection = () => {
//   const courses = [
//     {
//       icon: <FaBuilding className="text-blue-400 text-5xl" />,
//       title: "Civil Structure",
//       subtitle: "SAFE, ETABS, PROKON, STAAD Pro",
//       description:
//         "We provide recognized courses such as STAAD and ETABs courses Dubai to help you analyze, design, and construct building structures efficiently.",
//     },
//     {
//       icon: <FaCogs className="text-blue-400 text-5xl" />,
//       title: "Special Engineering",
//       subtitle: "Revit MEP & Auto CAD (2D & 3D)",
//       description:
//         "Gain essential and modern technical skills in engineering through our well-designed ELV course, ETAP software training, and PLC training courses.",
//     },
//     {
//       icon: <FaDraftingCompass className="text-blue-400 text-5xl" />,
//       title: "MEP Design/Engineering",
//       subtitle: "Plumbing, HVAC, Fire Fighting, Electrical",
//       description:
//         "Take your engineering and designing skills to the next level with our advanced professional courses and HVAC training in Dubai.",
//     },
//     {
//       icon: <FaCalculator className="text-blue-400 text-5xl" />,
//       title: "Estimation MEP & CIVIL",
//       subtitle: "Professional Estimation Training",
//       description:
//         "Our professional estimation courses help you manage civil projects effectively. Become certified MEP professionals with our quality training.",
//     },
//   ];

//   return (
//     <section className="bg-gray-900 text-white py-16 px-6">
//       <div className="max-w-6xl mx-auto text-center">
//         {/* Heading */}
//         <h2 className="text-3xl font-bold">Our Professional Courses</h2>
//         <p className="text-gray-400 mt-2 max-w-xl mx-auto">
//           Comprehensive training programs designed for your success
//         </p>
//       </div>

//       {/* Course Cards */}
//       <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
//         {courses.map((course, index) => (
//           <div
//             key={index}
//             className="bg-gray-800 p-6 rounded-lg shadow-lg transform transition duration-300 hover:scale-105"
//           >
//             <div className="flex justify-center">{course.icon}</div>
//             <h3 className="text-lg font-bold mt-4 text-center">{course.title}</h3>
//             <p className="text-blue-400 font-semibold text-center">{course.subtitle}</p>
//             <p className="text-gray-400 mt-2 text-center">{course.description}</p>
//           </div>
//         ))}
//       </div>

//       {/* View All Courses Button */}
//       <div className="mt-10 text-center">
//         <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-6 py-3 rounded-lg transition duration-300 transform hover:scale-105">
//           View All Courses
//         </button>
//       </div>
//     </section>
//   );
// };

// export default CoursesSection;


import React from "react";

const courses = [
  {
    title: "Civil Structure",
    image: "https://arabianinfotech.com/cache/menu/programs/program-preview-1.jpeg",
    description: "Learn STAAD, ETABS, SAFE, and PROKON for efficient structural analysis and design.",
    bgColor: "rgba(0, 0, 0, 0.6)",
  },
  {
    title: "Special Engineering Courses",
    image: "https://arabianinfotech.com/cache/menu/programs/program-preview-1.jpeg",
    description: "Gain expertise in Revit MEP, AutoCAD (2D & 3D), and specialized engineering skills.",
    bgColor: "rgba(0, 0, 0, 0.6)",
  },
  {
    title: "MEP Design/Engineering",
    image: "https://arabianinfotech.com/cache/menu/programs/program-preview-1.jpeg",
    description: "Plumbing, HVAC, Fire Fighting, Electrical - Advance your career with professional MEP training.",
    bgColor: "rgba(255, 175, 0, 0.8)",
  },
  {
    title: "MEP Industrial",
    image: "https://arabianinfotech.com/cache/menu/programs/program-preview-1.jpeg",
    description: "Comprehensive industrial MEP training for professionals and students.",
    bgColor: "rgba(0, 0, 0, 0.6)",
  },
  {
    title: "Estimation",
    image: "https://arabianinfotech.com/cache/menu/programs/program-preview-1.jpeg",
    description: "Master professional estimation techniques for MEP and Civil projects.",
    bgColor: "rgba(0, 0, 0, 0.6)",
  },
];

const CoursesSection = () => {
  return (
    <section className="py-16 bg-gray-800 text-white text-center">
      <h2 className="text-3xl sm:text-4xl font-bold mb-6">Our Professional Courses</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {courses.map((course, index) => (
          <div
            key={index}
            className="relative group overflow-hidden rounded-xl shadow-lg cursor-pointer w-full"
            style={{ height: "350px"}} // Adjusted box height
          >
            {/* Background Image */}
            <img
              src={course.image}
              alt={course.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />

            {/* Hover Overlay */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center p-6"
              style={{ backgroundColor: course.bgColor }}
            >
              <p className="text-white text-center text-lg">{course.description}</p>
            </div>

            {/* Title Always Visible */}
            <div className="absolute bottom-0 w-full bg-black bg-opacity-70 text-white py-3 text-lg sm:text-xl font-semibold text-center">
              {course.title}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default CoursesSection;

