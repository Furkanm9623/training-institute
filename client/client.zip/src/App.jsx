import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Navbar from './components/Navbar'
import Carousel from './components/Crousel'
import TrainingSection from './components/TrainingSection'
import CoursesSection from './components/CourseSection'
import WhyChooseUs from './components/WhyChooseUs'
import Testimonials from './components/Testimonials'
import ContactUs from './components/ContactUs'
import Footer from './components/Footer'
import Certifications from './components/Certification'
import AboutUs from './components/AboutUs'
import BottomNavbar from './components/BottomNavbar'


function App() {

  return (
    <>
       <Navbar/>
       {/* <BottomNavbar/> */}
       {/* <div className="w-screen"> */}
  <Carousel />
  <TrainingSection/>
  <CoursesSection/>
  <WhyChooseUs/>
  <Certifications/>
  <Testimonials/>
  <ContactUs/>
  {/* <AboutUs/> */}
  <Footer/>
{/* </div> */}
    </>
  )
}

export default App
