import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FaBars, FaTimes, FaPhone, FaEnvelope, FaWhatsapp } from "react-icons/fa";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToContact = () => {
    const contactSection = document.getElementById("contact-us");
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav className="bg-gray-800 text-white p-3 fixed w-full top-0 z-50 shadow-lg">
      <div className="container mx-auto flex justify-between items-center px-4 md:px-6">

        {/* Left Section: Logo */}
        <div className="flex items-center space-x-2">
          <img
            src="https://i.pinimg.com/236x/ba/93/38/ba9338d1b2d869497e27bee86cef8f8d.jpg"
            alt="logo"
            className="w-12 h-12 object-cover rounded-full"
          />
          <span className="text-lg font-bold">BIMBEES INFO TECH LTD.</span>
        </div>

        {/* Middle Section: Contact Details (Hidden on Mobile) */}
        <div className="hidden lg:flex space-x-6 text-sm">
          <div className="flex items-center space-x-2">
            <FaPhone />
            <span>+91 789654123</span>
          </div>
          <div className="flex items-center space-x-2">
            <FaPhone />
            <span>205056393 (UAE)</span>
          </div>
          <div className="flex items-center space-x-2">
            <FaWhatsapp />
            <span>+91 859652635</span>
          </div>
          <div className="flex items-center space-x-2">
            <FaEnvelope />
            <span>bimbessinfotech@gmail.com</span>
          </div>
        </div>

        {/* Right Section: Navigation & India Flag */}
        <div className="hidden md:flex items-center space-x-6">
          <Link to="/" className="hover:text-yellow-400 transition">Home</Link>
          <Link to="/about" className="hover:text-yellow-400 transition">About</Link>
          <Link to="/contact" onClick={scrollToContact} className="hover:text-yellow-400 transition">Contact</Link>
          <img
            src="https://upload.wikimedia.org/wikipedia/en/4/41/Flag_of_India.svg"
            alt="India Flag"
            className="w-6 h-4"
          />
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-gray-800 text-center py-4 absolute top-full w-full left-0">
          <Link to="/" className="block py-2 hover:text-yellow-400" onClick={() => setIsOpen(false)}>Home</Link>
          <Link to="/about" className="block py-2 hover:text-yellow-400" onClick={() => setIsOpen(false)}>About</Link>
          <Link to="/contact" className="block py-2 hover:text-yellow-400" onClick={() => setIsOpen(false)}>Contact</Link>
          <div className="flex justify-center mt-3">
            <img
              src="https://upload.wikimedia.org/wikipedia/en/4/41/Flag_of_India.svg"
              alt="India Flag"
              className="w-6 h-4"
            />
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
